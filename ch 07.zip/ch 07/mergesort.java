import java.util.*;

public class mergesort 
{
	public static void main(String[] args) 
	{
		
		Integer[] a = { 82, 12, 41, 38, 19, 26,9, 48, 20, 55,8 ,32, 3 };
		
		
		mergeSort(a);
		
		
		System.out.println(Arrays.toString(a));
	}

	 
	public static Comparable[] mergeSort(Comparable[] list) 
	{
		//Jika daftar kosong; tidak perlu melakukan apapun
        if (list.length <= 1) {
            return list;
        }
        
        //Membagi array menjadi dua menjadi dua bagian
        Comparable[] first = new Comparable[list.length / 2];
        Comparable[] second = new Comparable[list.length - first.length];
        System.arraycopy(list, 0, first, 0, first.length);
        System.arraycopy(list, first.length, second, 0, second.length);
        
        //Urutkan masing-masing setengah secara rekursif
        mergeSort(first);
        mergeSort(second);
        
        //Gabungkan kedua bagian menjadi satu, timpa ke array asli
        merge(first, second, list);
        return list;
    }
    
	@SuppressWarnings({ "rawtypes", "unchecked" }) 
    private static void merge(Comparable[] first, Comparable[] second, Comparable[] result) 
	{
        //Posisi Indeks dalam array pertama - dimulai dengan elemen pertama
        int iFirst = 0;
        
        //Posisi Indeks dalam array kedua - dimulai dengan elemen pertama
        int iSecond = 0;
        
        //Posisi Indeks dalam array yang digabung - dimulai dengan posisi pertama
        int iMerged = 0;
        
       
        while (iFirst < first.length && iSecond < second.length) 
        {
            if (first[iFirst].compareTo(second[iSecond]) < 0) 
            {
                result[iMerged] = first[iFirst];
                iFirst++;
            } 
            else 
            {
                result[iMerged] = second[iSecond];
                iSecond++;
            }
            iMerged++;
        }
        
        System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);
        System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);
    }
}