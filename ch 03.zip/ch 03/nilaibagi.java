public class nilaibagi{
	public static void main(String[] args) {
		int a = 6,b = 3;
		int bagi =a/b;
		System.out.println(" nilai bagi selain 1&2");
	}
}