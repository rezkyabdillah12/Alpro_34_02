public class BilanganTerbesar1 {
	public static void main(String[] args) {
		int x = 10;
		int y = 5;
		if(x<y){
		System.out.println("nilai" +y+ "adalah nilai terbesar");
		} else {
			System.out.println ("nilai" +x+ "adalah nilai terbesar");
		}
	}
}