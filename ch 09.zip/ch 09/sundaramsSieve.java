import java.util.*;
import javax.swing.JOptionPane;
public class sundaramsSieve
{
    public static void main(String[] args)
    {   
        int[] primes;      
       String arraySizeStr;
       int arraySize;       
             arraySizeStr=
            JOptionPane.showInputDialog("Masukkan nomor untuk menemukan semua" + 
                                 " nomor.");
            arraySize = Integer.parseInt(arraySizeStr);                      
                  primes = SundaramSieve.findPrimes(arraySize);              
        for (int prime : primes)
       {
           System.out.print(prime + " ");
        }
          System.out.println();
          System.out.print("Selesai!");                   
    }       
       static public class SundaramSieve 
       {         
            public static int[] findPrimes(int arraySize)
         {//mulai int statis publik
            int n = arraySize / 2;
            boolean[] isPrime = new boolean[arraySize];
            Arrays.fill(isPrime, true);
            for (int i = 1; i < n; i++)
          {
                for (int j = i; j <= (n - i) / (2 * i + 1); j++)
             {
                    isPrime[i + j + 2 * i * j] = false;
                }
            }               
            int[] primes = new int[arraySize];
            int found = 0;
           
            if (arraySize > 2) {
                primes[found++] = 2;
            }
            for (int i = 1; i < n; i++)
          {
                if (isPrime[i])
              {
                    primes[found++] = i * 2 + 1;
                }
            }               
            return Arrays.copyOf(primes, found);
        }//akhir int statis publik
    }
}