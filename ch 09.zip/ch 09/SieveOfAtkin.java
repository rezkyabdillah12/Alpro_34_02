/**
 ** Program Java untuk mengimplementasikan generatio Sieve Of Atkin Primen
 **/
 
import java.util.Scanner;
 
/** Class SieveOfAtkin **/
public class  SieveOfAtkin
{
    /** Berfungsi untuk menghitung semua bilangan prima kurang dari n **/
    private boolean[] calcPrimes(int limit)
    {
        /** nisialisasi saringan **/
        boolean[] prime = new boolean[limit + 1];
        prime[2] = true;
        prime[3] = true;
        int root = (int) Math.ceil(Math.sqrt(limit));
 
       
        for (int x = 1; x < root; x++)
        {
            for (int y = 1; y < root; y++)
            {
                int n = 4 * x * x + y * y;
                if (n <= limit && (n % 12 == 1 || n % 12 == 5))
                    prime[n] = !prime[n];
                n = 3 * x * x + y * y;
                if (n <= limit && n % 12 == 7)
                    prime[n] = !prime[n];
                n = 3 * x * x - y * y;
                if ((x > y) && (n <= limit) && (n % 12 == 11))
                    prime[n] = !prime[n];
            }
        }
        /** menghilangkan komposit dengan menyaring, menghilangkan kelipatan dari kuadratnya **/
        for (int i = 5; i <= root; i++)
            if (prime[i])
                for (int j = i * i; j < limit; j += i * i)
                    prime[j] = false;
 
        return prime;
    }
    /** Berfungsi untuk mendapatkan semua bilangan prima **/
    public void getPrimes(int N)
    {
        boolean[] primes = calcPrimes(N);
        display(primes);
    }
    /** Berfungsi untuk mendapatkan semua bilangan prima **/
    public void display(boolean[] primes)
    {
        System.out.print("\nprima = ");
        for (int i = 2; i < primes.length; i++)
            if (primes[i])
                System.out.print(i +" ");
        System.out.println();
    }
    /**fungsi utama**/
    public static void main (String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Sieve Of Atkin Prime Algorithm Test\n");
        /** Buat objek dari kelas SieveOfAtkin **/
         SieveOfAtkin soa = new  SieveOfAtkin();
        /** Terima n **/
        System.out.println("Masukkan nomor untuk menemukan semua bilangan prima kurang dari nomor\n");
        int n = scan.nextInt();
        soa.getPrimes(n);        
    }
}