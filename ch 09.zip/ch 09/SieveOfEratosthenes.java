
  
class SieveOfEratosthenes 
{ 
    void sieveOfEratosthenes(int n) 
    { 
       
        boolean prime[] = new boolean[n+1]; 
        for(int i=0;i<n;i++) 
            prime[i] = true; 
          
        for(int p = 2; p*p <=n; p++) 
        { 
            // Jika prime [p] tidak diubah, maka itu adalah prime
            if(prime[p] == true) 
            { 
                // Perbarui semua kelipatan  
                for(int i = p*2; i <= n; i += p) 
                    prime[i] = false; 
            } 
        } 
          
        // Cetak semua bilangan prima 
        for(int i = 2; i <= n; i++) 
        { 
            if(prime[i] == true) 
                System.out.print(i + " "); 
        } 
    } 
      
    // Program Driver untuk menguji fungsi di atas 
    public static void main(String args[]) 
    { 
        int n = 15; 
        System.out.print("Berikut ini adalah bilangan prima "); 
        System.out.println("lebih kecil dari atau sama dengan " + n); 
        SieveOfEratosthenes g = new SieveOfEratosthenes(); 
        g.sieveOfEratosthenes(n); 
    } 
} 