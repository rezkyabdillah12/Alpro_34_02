public class salam3 {
    public static void main (String[] args){
        //Baris ini tidak di compile
        System.out.println ("1 Baris berhasil di compile!");  
    }
}