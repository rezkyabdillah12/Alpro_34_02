public class salam4 {
    public static void main (String[] args){
        String nama = " udin";
        System.out.println ("Hai " + nama);
    }
}