class LIS { 
    
    static int lis(int arr[], int n) 
    { 
        int lis[] = new int[n]; 
        int i, j, max = 0; 
  
        /* Inisialisasi nilai LIS untuk semua indeks */
        for (i = 0; i < n; i++) 
            lis[i] = 1; 
  
        /*Hitung nilai LIS yang dioptimalkan dengan cara dari bawah ke atas */
        for (i = 1; i < n; i++) 
            for (j = 0; j < i; j++) 
                if (arr[i] > arr[j] && lis[i] < lis[j] + 1) 
                    lis[i] = lis[j] + 1; 
  
        /* Pilih maksimum semua nilai LIS */
        for (i = 0; i < n; i++) 
            if (max < lis[i]) 
                max = lis[i]; 
  
        return max; 
    } 
  
    public static void main(String args[]) 
    { 
        int arr[] = { 999, 222, 559, 233, 121, 250, 641, 460 }; 
        int n = arr.length; 
        System.out.println("panjangnya adola " + lis(arr, n) + "\n"); 
    } 
} 