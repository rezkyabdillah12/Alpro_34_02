package ch02;
public class PersegiPanjang {
    int panjang;
    int lebar;
    int luas () {
        return panjang * lebar;
    }
}