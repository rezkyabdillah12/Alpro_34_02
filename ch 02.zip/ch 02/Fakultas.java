package ch02;

public class Fakultas {

    String nama;
    int jumlahMahasiswa;

    public String getNama() {
        return nama;
    }
    public int getJumlahMahasiswa() {
        return jumlahMahasiswa;
    }
}
