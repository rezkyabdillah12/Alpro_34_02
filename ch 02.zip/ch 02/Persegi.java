package ch02;

public class Persegi {

    int sisi ;
    int luas () {
        return sisi*sisi ;

    }
}
