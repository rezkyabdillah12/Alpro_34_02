/**
 ** Program Java untuk mengimplementasikan Algoritma Knuth Morris Pratt
 **/
 
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
 
/** Kelas KnuthMorrisPratt **/
public class KnuthMorrisPratt
{
    /** himpunan kegagalan **/
    private int[] failure;
    /** Konstruktor **/
    public KnuthMorrisPratt(String text, String pat)
    {
        /** susunan kegagalan untuk suatu pola **/
        failure = new int[pat.length()];
        fail(pat);
        /** Temukan pasangan **/
        int pos = posMatch(text, pat);
        if (pos == -1)
            System.out.println("\nNo match found");
        else
            System.out.println("\nMatch found at index "+ pos);
    }
    /** Fungsi kegagalan untuk suatu pola **/
    private void fail(String pat)
    {
        int n = pat.length();
        failure[0] = -1;
        for (int j = 1; j < n; j++)
        {
            int i = failure[j - 1];
            while ((pat.charAt(j) != pat.charAt(i + 1)) && i >= 0)
                i = failure[i];
            if (pat.charAt(j) == pat.charAt(i + 1))
                failure[j] = i + 1;
            else
                failure[j] = -1;
        }
    }
    /** Berfungsi untuk menemukan kecocokan untuk suatu pola **/
    private int posMatch(String text, String pat)
    {
        int i = 0, j = 0;
        int lens = text.length();
        int lenp = pat.length();
        while (i < lens && j < lenp)
        {
            if (text.charAt(i) == pat.charAt(j))
            {
                i++;
                j++;
            }
            else if (j == 0)
                i++;
            else
                j = failure[j - 1] + 1;
        }
        return ((j == lenp) ? (i - lenp) : -1);
    }
    /** Fungsi utama **/
    public static void main(String[] args) throws IOException
    {    
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Knuth Morris Pratt Test\n");
        System.out.println("\nMasukkan teks\n");
        String text = br.readLine();
        System.out.println("\nMasukkan pola\n");
        String pattern = br.readLine();
        KnuthMorrisPratt kmp = new KnuthMorrisPratt(text, pattern);        
    }
}